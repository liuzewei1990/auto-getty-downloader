// 常量定义
const API_HOST = "https://galagetter.cc";
const MESSAGE_TYPES = {
  SUCCESS: "success",
  FAILURE: "failure",
  PENDING: "pending",
  WARNING: "warning",
  UPGRADE: "upgrade",
  MANUAL_CHECK: "manualCheck"
};
const API_ENDPOINTS = {
  SIGN_IN: "/api/signin/",
  TASK_LIST: "/api/tasklist/",
  TASK_CLEAR: "/api/taskclear/",
  USER_CREDITS: "/users/credits/",
  CONSULT: "/api/consult/",
  ANNOUNCEMENT: "/api/announcement/",
  UPDATE_NOTES: "/api/updatenotes/"
};
const STORAGE_KEYS = {
  TOKEN: "token",
  REFRESH_TOKEN: "refresh_token",
  UPDATE_AVAILABLE: "updateAvailable",
  NEW_VERSION: "newVersion",
  DOWNLOAD_LINK: "downloadLink"
};
const TASK_STATUS = {
  SUCCESS: "SUCCESS",
  FAILURE: "FAILURE",
  PENDING: "pending",
  PROCESSING: "Processing"
};
const TYPE_NAMES = {
  GETTY_CHROME: "getty_chrome",
  ALAMY_CHROME: "alamy_chrome",
  IMAGO_CHROME: "imago_chrome",
  AP_CHROME: "ap_chrome",
  FREEMPIK_CHROME: "freepik_chrome",
  SHUTTERSTOCK_CHROME: "shutterstock_chrome",
  ISTOCK_CHROME: "istock_chrome",
  ADOBESTOCK_CHROME: "adobestock_chrome"
};

// DOM元素引用
const loginButton = document.querySelector("#loginButton");
const logoutButton = document.querySelector("#logoutButton");
let clearButton = document.querySelector("#clearButton");
const currentUrl = window.location.pathname;
const isProfilePage = currentUrl.includes("profile.html");
const isLoginPage = currentUrl.includes("login.html");

// 全局变量
let lazyLoadInstance;

/**
 * 初始化事件监听器
 */
function initEventListeners() {
  // 监听来自background.js的消息
  chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    console.log("Received message:", message);
    
    // 根据消息类型执行相应操作
    if (message.type === MESSAGE_TYPES.SUCCESS || 
        message.type === MESSAGE_TYPES.FAILURE || 
        message.type === MESSAGE_TYPES.PENDING || 
        message.type === MESSAGE_TYPES.WARNING) {
      const token = await checkToken();
      await getTasks(token);
      await getCredits(token);
    }
    
    if (message.type === MESSAGE_TYPES.UPGRADE) {
      if (message.data.status) updateUI();
      
      const updateButton = document.getElementById("updateBtn");
      const versionElement = document.getElementById("version");
      const checkUpdateButton = document.querySelector("#checkUpdateBtn");
      
      if (updateButton) updateButton.style.display = "block";
      if (versionElement) versionElement.style.display = "block";
      if (checkUpdateButton) checkUpdateButton.style.display = "none";
    }
  });
  
  // 页面加载完成事件
  document.addEventListener("DOMContentLoaded", async function() {
    // 设置版本号
    const manifestVersion = chrome.runtime.getManifest().version;
    const versionElement = document.querySelector("#version");
    if (versionElement) versionElement.textContent = manifestVersion;
    
    // 更新UI和显示公告
    updateUI();
    showAnnouncement();
    
    // 检查更新按钮点击事件
    const checkUpdateButton = document.querySelector("#checkUpdateBtn");
    if (checkUpdateButton) {
      checkUpdateButton.addEventListener("click", function() {
        const buttonSpan = document.querySelector("#checkUpdateBtn span");
        const versionElement = document.getElementById("version");
        const loadingElement = document.querySelector(".loading");
        
        if (buttonSpan) buttonSpan.style.display = "none";
        if (versionElement) versionElement.style.display = "none";
        if (loadingElement) loadingElement.style.display = "block";
        
        chrome.runtime.sendMessage({ type: MESSAGE_TYPES.MANUAL_CHECK });
      });
    }
    
    // 确定路由（登录页或个人资料页）
    getRoute();
  });
  
  // 登录按钮点击事件
  if (loginButton) {
    loginButton.addEventListener("click", function(event) {
      event.preventDefault();
      signIn();
    });
  }
  
  // 登录页特殊处理
  if (isLoginPage) {
    // 用户名输入框回车事件
    document.querySelector("#username").addEventListener("keydown", function(event) {
      if (event.key === "Enter") signIn();
    });
    
    // 密码输入框回车事件
    document.getElementById("password").addEventListener("keydown", function(event) {
      if (event.key === "Enter") signIn();
    });
    
    // 输入时隐藏错误信息
    document.querySelector("#username").addEventListener("input", hideError);
    document.getElementById("password").addEventListener("input", hideError);
  }
  
  // 注销按钮点击事件
  if (logoutButton) {
    logoutButton.addEventListener("click", function() {
      chrome.storage.local.remove(
        [STORAGE_KEYS.TOKEN, STORAGE_KEYS.REFRESH_TOKEN, "taskCount"],
        function() {
          clearBadge();
          loadLoginPage();
        }
      );
    });
  }
  
  // 清除任务按钮点击事件
  if (clearButton) {
    clearButton.addEventListener("click", async function(event) {
      const result = await Swal.fire({
        title: "Are you sure?",
        text: "You will delete all tasks. You won't be able to revert this!",
        icon: "warning",
        width: "24em",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Confirm",
      });
      
      if (result.isConfirmed) {
        Swal.fire({
          title: "Deleting...",
          text: "Please wait a moment.",
          icon: "info",
          allowOutsideClick: false,
        });
        
        Swal.showLoading();
        let response = await clearTasks();
        
        if (response && response.status === 200) {
          Swal.close();
          const token = await checkToken();
          await getTasks(token);
          await getCredits(token);
          Swal.fire({ 
            title: "Deleted!", 
            text: "Your file has been deleted.", 
            icon: "success" 
          });
        } else {
          Swal.close();
          Swal.fire({ 
            title: "Error!", 
            text: "Something went wrong", 
            icon: "error" 
          });
        }
      }
    });
  }
  
  // 初始化懒加载
  document.addEventListener("DOMContentLoaded", initLazyLoad);
}

/**
 * 更新UI，显示更新信息
 */
function updateUI() {
  chrome.storage.local.get(
    [STORAGE_KEYS.UPDATE_AVAILABLE, STORAGE_KEYS.NEW_VERSION, STORAGE_KEYS.DOWNLOAD_LINK],
    async function(items) {
      const updateWrap = document.querySelector("updateWrap");
      const updateMessage = document.querySelector("#updateMessage");
      const updateButton = document.querySelector("#updateBtn");
      
      if (items.updateAvailable) {
        if (updateWrap) updateWrap.classList.remove("d-none");
        
        if (updateMessage) {
          updateMessage.textContent = "New version " + items.newVersion + " available!";
          const updateNotesContent = document.getElementById("updateNotes-content");
          
          if (updateNotesContent) {
            try {
              const response = await fetch(API_HOST + API_ENDPOINTS.UPDATE_NOTES);
              if (response.ok) {
                const data = await response.json();
                const notes = data.update_notes;
                if (notes) {
                  updateNotesContent.innerHTML = notes;
                }
              }
            } catch (error) {
              console.error("Error fetching update notes:", error);
            }
          }
        }
        
        if (updateButton) {
          updateButton.href = items.downloadLink;
          updateButton.style.display = "block";
        }
      } else {
        if (updateWrap) updateWrap.classList.add("d-none");
        if (updateMessage) updateMessage.textContent = "";
        if (updateButton) updateButton.style.display = "none";
      }
    }
  );
}

/**
 * 显示公告
 */
async function showAnnouncement() {
  const announcementElement = document.querySelector("#announcement");
  const announcementContent = document.querySelector("#announcement-content");
  
  if (announcementElement) {
    try {
      const response = await fetch(API_HOST + API_ENDPOINTS.ANNOUNCEMENT);
      if (response.ok) {
        const data = await response.json();
        const isActive = data.announcement;
        const content = data.content;
        
        if (isActive) {
          announcementElement.classList.remove("d-none");
          if (announcementContent) {
            announcementContent.textContent = content;
          }
        } else {
          announcementElement.classList.add("d-none");
        }
      }
    } catch (error) {
      console.error("Error fetching announcement:", error);
    }
  }
}

/**
 * 发送消息到background.js
 * @param {Object} message - 要发送的消息
 * @returns {Promise} - 返回Promise对象
 */
function sendMessagePromise(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}

/**
 * 获取任务列表
 * @param {string} token - 用户令牌
 */
async function getTasks(token) {
  if (!token) return;
  
  try {
    const response = await fetch(API_HOST + API_ENDPOINTS.TASK_LIST, {
      method: "GET",
      headers: { 
        Authorization: "Bearer " + token, 
        "Content-Type": "application/json" 
      },
    });
    
    const data = await response.json();
    console.log(data);
    renderTaskList(data);
  } catch (error) {
    console.error("Error fetching tasks:", error);
  }
}

/**
 * 获取用户积分
 * @param {string} token - 用户令牌
 */
async function getCredits(token) {
  if (!token) return;
  
  const noCreditsElement = document.querySelector("#nocredits");
  
  try {
    const response = await fetch(API_HOST + API_ENDPOINTS.USER_CREDITS, {
      method: "GET",
      headers: {
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
      },
    });
    
    // 处理403错误（未授权）
    if (response.status === 403) {
      chrome.storage.local.remove(
        [STORAGE_KEYS.TOKEN, STORAGE_KEYS.REFRESH_TOKEN, "taskCount"],
        function() {
          clearBadge();
          loadLoginPage();
        }
      );
    }
    
    const data = await response.json();
    
    if (data) {
      const creditsElement = document.querySelector("#credits");
      if (creditsElement) {
        creditsElement.textContent = "" + data.credits;
      }
      
      // 积分不足时显示咨询信息
      if (data.credits < 1) {
        getConsult(token);
        if (noCreditsElement) {
          noCreditsElement.classList.remove("d-none");
          noCreditsElement.classList.add("block");
        }
      } else if (noCreditsElement) {
        noCreditsElement.classList.add("d-none");
      }
    }
  } catch (error) {
    console.error("Error fetching credits:", error);
  }
}

/**
 * 获取咨询信息
 * @param {string} token - 用户令牌
 * @returns {Promise} - 返回咨询信息
 */
async function getConsult(token) {
  const noCreditsElement = document.getElementById("nocredits");
  const consultElement = document.querySelector("#consult");
  const qrcodeElement = document.querySelector("#qrcode");
  
  if (!consultElement) return;
  
  try {
    const response = await fetch(API_HOST + API_ENDPOINTS.CONSULT, {
      method: "GET",
      headers: {
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
      },
    });
    
    console.log("getConsult: " + response.status);
    
    if (response.ok) {
      const data = await response.json();
      
      if (data) {
        consultElement.innerHTML = data.consult;
        if (qrcodeElement) {
          qrcodeElement.src = API_HOST + data.qrcode;
        }
        
        // 添加鼠标悬停和离开事件
        if (noCreditsElement) {
          noCreditsElement.addEventListener("mouseover", function() {
            if (qrcodeElement) {
              qrcodeElement.style.transform = "scale(2.5) translateX(-10px)";
              qrcodeElement.style.transition = "transform 0.3s";
              qrcodeElement.style.zIndex = "10";
            }
          });
          
          noCreditsElement.addEventListener("mouseout", function() {
            if (qrcodeElement) {
              qrcodeElement.style.transform = "scale(1)";
              qrcodeElement.style.zIndex = "1";
            }
          });
        }
        
        return data.consult;
      }
    }
  } catch (error) {
    console.error("Error fetching consult:", error);
  }
}

/**
 * 显示加载状态
 * @param {boolean} show - 是否显示加载状态
 */
async function showLoading(show) {
  const loadingElement = document.querySelector(".loading");
  if (loadingElement) {
    loadingElement.style.display = show ? "block" : "none";
  }
}

/**
 * 显示错误消息
 * @param {string} message - 错误消息
 */
function showError(message) {
  const errorElement = document.getElementById("error-message");
  if (errorElement) {
    errorElement.textContent = message;
    errorElement.style.display = "block";
  }
}

/**
 * 隐藏错误消息
 */
function hideError() {
  const errorElement = document.querySelector("#error-message");
  if (errorElement) {
    errorElement.style.display = "none";
  }
}

/**
 * 加载登录页面
 */
function loadLoginPage() {
  chrome.action.setPopup({ popup: "/popup/login.html" });
  window.location.pathname = "/popup/login.html";
}

/**
 * 加载个人资料页面
 * @param {Object} user - 用户信息（可选）
 */
function loadProfilePage(user) {
  chrome.action.setPopup({ popup: "/popup/profile.html" });
  window.location.pathname = "/popup/profile.html";
}

/**
 * 用户登录
 */
async function signIn() {
  await showLoading(true);
  hideError();
  
  const username = document.querySelector("#username").value.trim();
  const password = document.getElementById("password").value;
  
  if (!username || !password) {
    showError("Please enter both username and password.");
    await showLoading(false);
    return;
  }
  
  try {
    const response = await fetch(API_HOST + API_ENDPOINTS.SIGN_IN, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: username, password: password }),
    });
    
    if (response.status === 403) {
      showLoading(false);
      showError("Please check your username or password");
      return;
    }
    
    if (!response.ok) {
      showLoading(false);
      showError("An error occurred during login");
      return;
    }
    
    const data = await response.json();
    showLoading(false);
    
    if (data.token && data.refresh_token) {
      chrome.storage.local.set(
        { token: data.token, refresh_token: data.refresh_token },
        function() {
          loadProfilePage(data.user);
        }
      );
    } else {
      showError(data || "An error occurred during login");
    }
  } catch (error) {
    await showLoading(false);
    
    if (error.message === "Failed to fetch") {
      showError("Failed to fetch");
      return;
    }
    
    showError(error.message || "Failed to fetch");
  }
}

/**
 * 清除任务历史
 * @returns {Promise<Response|null>} - 返回响应或null
 */
async function clearTasks() {
  const token = await checkToken();
  
  if (token) {
    try {
      const response = await fetch(API_HOST + API_ENDPOINTS.TASK_CLEAR, {
        method: "POST",
        headers: { 
          Authorization: "Bearer " + token, 
          "Content-Type": "application/json" 
        },
      });
      
      if (response.status === 200) return response;
      return null;
    } catch (error) {
      console.error("Error clearing history:", error);
      return null;
    }
  }
  
  return null;
}

/**
 * 确定当前路由
 */
async function getRoute() {
  const token = await checkToken();
  
  if (token) {
    if (!isProfilePage) {
      loadProfilePage();
    }
    
    await getCredits(token);
    await getTasks(token);
    return;
  }
  
  if (!token && !isLoginPage) {
    loadLoginPage();
  }
}

/**
 * 检查用户令牌是否有效
 * @returns {Promise<string|null>} - 返回令牌或null
 */
async function checkToken() {
  return new Promise((resolve) => {
    chrome.storage.local.get(
      [STORAGE_KEYS.TOKEN, STORAGE_KEYS.REFRESH_TOKEN],
      function(items) {
        if (items.token && items.refresh_token) {
          resolve(items.token);
        } else {
          resolve(null);
        }
      }
    );
  });
}

/**
 * 渲染任务列表
 * @param {Object} data - 任务数据
 */
function renderTaskList(data) {
  const taskContainer = document.querySelector("#taskContainer");
  if (!taskContainer) return;
  
  taskContainer.innerHTML = "";
  
  if (data.length === 0) {
    taskContainer.innerHTML = 
      '<div id="taskContainer" class="d-flex h-100 justify-content-center align-items-center">No tasks.</div>';
    return;
  }
  
  let htmlContent = `
    <table class="table table-getty align-middle table-edge table-hover table-nowrap mb-0 p-3">
      <thead>
        <tr>
          <th scope="col">Image</th>
          <th scope="col">Status</th>
          <th scope="col">Credits</th>
          <th scope="col">Link</th>
        </tr>
      </thead>
      <tbody>
  `;
  
  data.forEach(task => {
    console.log(task.type);
    
    // 根据任务类型获取图标HTML
    let iconHtml = getSourceIconHtml(task.type_name);
    
    // 构建表格行HTML
    htmlContent += `
      <tr>
        <td scope="row">
          <div class="d-flex align-items-center gap-3">
            <a href="${task.landingUrl}" target="_blank" class="landing-link position-relative">
              <img class="lazy rounded-2" data-src="${task.url_thumb_nw}" width=48 height=48/>
              ${iconHtml}
            </a>
          </div>
        </td>
        <td>
          <div class="align-items-center">
            ${getStatusHtml(task.status)}
          </div>
        </td>
        <td class="text-center">
          ${task.credits !== 0 ? "-" + task.credits : task.credits}
        </td>
        <td>
          <a class="btn btn-sm ${!task.url ? "btn-outline-secondary disabled" : "btn-outline-brand"}" href="${API_HOST}/${task.url}" download>Download</a>
        </td>
      </tr>
    `;
  });
  
  // 添加表格结束标签和声明
  htmlContent += `
        <tr>
          <td colspan="4">
            <div class="statement">
              Downloaded images will be retained for 48 hours
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  `;
  
  taskContainer.innerHTML = htmlContent;
  
  // 初始化懒加载
  if (lazyLoadInstance) {
    lazyLoadInstance.update();
  }
}

/**
 * 根据源类型获取图标HTML
 * @param {string} typeName - 源类型名称
 * @returns {string} - 图标HTML
 */
function getSourceIconHtml(typeName) {
  switch (typeName) {
    case TYPE_NAMES.GETTY_CHROME:
      return '<span class="position-absolute bottom-0 end-0"><img src="/images/icon_getty.png" width=16 height=16 class="border border-0 border-radius-50" /></span>';
    case TYPE_NAMES.ALAMY_CHROME:
      return '<span class="position-absolute bottom-0 end-0"><img src="/images/icon_alamy.png" width=16 height=16 class="border border-0 border-radius-50" /></span>';
    case TYPE_NAMES.IMAGO_CHROME:
      return '<span class="position-absolute bottom-0 end-0"><img src="/images/icon_imago.png" width=16 height=16 class="border border-0 border-radius-50" /></span>';
    case TYPE_NAMES.AP_CHROME:
      return '<span class="position-absolute bottom-0 end-0"><img src="/images/icon_ap.png" width=16 height=16 class="border border-0 border-radius-50" /></span>';
    case TYPE_NAMES.FREEMPIK_CHROME:
      return '<span class="position-absolute bottom-0 end-0"><img src="/images/icon_freepik.png" width=16 height=16 class="border border-0 border-radius-50" /></span>';
    case TYPE_NAMES.SHUTTERSTOCK_CHROME:
      return '<span class="position-absolute bottom-0 end-0"><img src="/images/icon_shutterstock.png" width=16 height=16 class="border border-0 border-radius-50" /></span>';
    case TYPE_NAMES.ISTOCK_CHROME:
      return '<span class="position-absolute bottom-0 end-0"><img src="/images/icon_istockphoto.png" width=16 height=16 class="border border-0 border-radius-50" /></span>';
    case TYPE_NAMES.ADOBESTOCK_CHROME:
      return '<span class="position-absolute bottom-0 end-0"><img src="/images/icon_adobestock.png" width=16 height=16 class="border border-0 border-radius-50" /></span>';
    default:
      return '';
  }
}

/**
 * 根据任务状态获取状态HTML
 * @param {string} status - 任务状态
 * @returns {string} - 状态HTML
 */
function getStatusHtml(status) {
  if (status === TASK_STATUS.PROCESSING) {
    return `<div class="d-flex align-items-center justify-content-left">
      <span class="spinner-grow spinner-grow-sm text-warning me-2" role="status" style="width: 0.8rem; height: 0.8rem;"></span>
      <span>${status}</span>
    </div>`;
  } else {
    return `<span>${status}</span>`;
  }
}

/**
 * 清除徽章
 */
function clearBadge() {
  chrome.action.setBadgeText({ text: "" });
}

/**
 * 显示通知
 * @param {string} title - 通知标题
 * @param {string} message - 通知消息
 */
async function notice(title, message) {
  const iconUrl = chrome.runtime.getURL("/images/icon-48.png");
  
  chrome.notifications.create(
    { 
      type: "basic", 
      iconUrl: iconUrl, 
      title: title, 
      message: message 
    }, 
    function(notificationId) {
      if (chrome.runtime.lastError) {
        console.error(chrome.runtime.lastError.message);
      } else {
        console.log(notificationId);
      }
    }
  );
}

/**
 * 初始化图片懒加载
 */
function initLazyLoad() {
  lazyLoadInstance = new LazyLoad({ 
    rootMargin: "0px", 
    threshold: 0.1 
  });
}

// 初始化事件监听器
initEventListeners();