// Getty Images 下载助手扩展脚本
// 功能：为Getty Images网站添加下载按钮，支持搜索页面和详情页面

// 常量定义 - 提高代码可读性和维护性
const PAGE_TYPES = {
  SEARCH: "search",
  DETAIL: "detail",
};

const MESSAGE_TYPES = {
  DOWNLOADED: "downloaded",
  ERROR: "error",
  WARNING: "warning",
};

// DOM选择器常量
const SELECTORS = {
  DETAIL_PREVIEW: 'figure[data-testid="image-card"]',
  SEARCH_PREVIEW: 'div[data-testid="galleryMosaicAsset"] > article',
  THUMB_IMAGE: "img",
};

// 按钮内容常量
const BUTTON_CONTENT = {
  DOWNLOAD: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
    <path d="M14,14H2a1,1,0,0,0,0,2H14a1,1,0,0,0,0-2Z" fill="#000000"></path>
    <path d="M7.293,11.707a1,1,0,0,0,1.414,0l5-5a1,1,0,1,0-1.414-1.414L9,8.586V1A1,1,0,0,0,7,1V8.586L3.707,5.293A1,1,0,0,0,2.293,6.707Z"></path>
  </svg>Download`,
  WAITING: `<svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 16 16">
    <title>dots anim 2</title>
    <g fill="#000000" class="nc-icon-wrapper">
      <g class="nc-loop-dots-2-16-icon-f">
        <circle cx="8" cy="1.5" fill="#000000" r="1.5" opacity="0.6"></circle>
        <circle cx="12.596" cy="3.404" fill="#000000" r="1.5" opacity="0.8"></circle>
        <circle cx="14.5" cy="8" fill="#000000" r="1.5"></circle>
        <circle cx="12.596" cy="12.596" fill="#000000" r="1.5" opacity="0.4"></circle>
        <circle cx="8" cy="14.5" fill="#000000" r="1.5" opacity="0.4"></circle>
        <circle cx="3.404" cy="12.596" fill="#000000" r="1.5" opacity="0.4"></circle>
        <circle cx="1.5" cy="8" fill="#000000" r="1.5" opacity="0.4"></circle>
        <circle cx="3.404" cy="3.404" fill="#000000" r="1.5" opacity="0.4"></circle>
      </g>
      <style>.nc-loop-dots-2-16-icon-f{--animation-duration:0.8s;transform-origin:8px 8px;animation:nc-loop-dots-2-anim var(--animation-duration) infinite steps(8,start)}@keyframes nc-loop-dots-2-anim{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}</style>
    </g>
  </svg>Waiting`,
  ADDED: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"></path>
  </svg>Added`,
};

// 通知消息常量
const MESSAGES = {
  DOWNLOADED_TITLE: "Added to download",
  DOWNLOADED_TEXT: "The image has been added to the download list.",
  LOGIN_REQUIRED: "Login required",
  DOWNLOAD_NOT_SUPPORTED:
    '<div> <span style="color: #ffdd00;">Download not supported</span></div>',
  ERROR_FETCHING: "Error fetching data: ",
  GETTY_DETAIL_URL: "https://www.gettyimages.com/detail/",
};

// 全局变量
let landingUrl = "";
let currentButton = null;
let currentUrl = window.location.href;
let currentPage = null;

/**
 * 初始化页面类型检测
 */
function detectPageType() {
  if (
    currentUrl.includes("/search") ||
    currentUrl.includes("/editorial-images")
  ) {
    currentPage = PAGE_TYPES.SEARCH;
  } else if (currentUrl.includes("/detail/")) {
    currentPage = PAGE_TYPES.DETAIL;
  } else {
    currentPage = null;
  }
}

/**
 * 检查用户登录状态
 * @returns {Promise<string|null>} 返回token或null
 */
async function checkToken() {
  return new Promise((resolve) => {
    chrome.storage.local.get(
      ["token", "refresh_token"],
      async function (result) {
        if (result.token && result.refresh_token) {
          resolve(result.token);
        } else {
          resolve(null);
        }
      }
    );
  });
}

/**
 * 创建下载按钮
 * @param {string} pageType - 页面类型（search或detail）
 * @returns {HTMLElement} 创建的下载按钮元素
 */
function createDownloadButton(pageType = null) {
  const button = document.createElement("a");
  button.innerHTML = BUTTON_CONTENT.DOWNLOAD;

  // 设置按钮样式
  Object.assign(button.style, {
    position: "absolute",
    top: "0",
    right: "0",
    zIndex: "11",
    width: "120px",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  });

  button.classList.add("download");
  button.download = true;

  // 根据页面类型绑定不同的点击事件
  if (pageType === PAGE_TYPES.DETAIL) {
    console.log("detail");
    button.addEventListener("click", handleDetailButtonClick);
  } else if (pageType === PAGE_TYPES.SEARCH) {
    console.log("search");
    button.addEventListener("click", handleSearchButtonClick);
  }

  return button;
}

/**
 * 处理详情页按钮点击
 * @param {Event} event - 点击事件
 */
async function handleDetailButtonClick(event) {
  event.stopPropagation();
  event.preventDefault();

  const button = event.currentTarget;
  if (button.innerHTML !== BUTTON_CONTENT.DOWNLOAD) return;

  const token = await checkToken();
  if (token) {
    button.innerHTML = BUTTON_CONTENT.WAITING;

    try {
      // 获取图片数据
      const scriptElement = document.querySelector(
        'script[data-component="AssetDetail"][type="application/json"]'
      );
      const scriptContent = scriptElement.textContent;

      // 提取缩略图URL
      const thumbRegex = /"Thumb612":"(.+?)"/;
      const thumbMatch = scriptContent.match(thumbRegex);
      const thumbUrlEncoded = thumbMatch[1];
      const thumbUrl = decodeURIComponent(
        thumbUrlEncoded.replace(/\\u[\dA-F]{4}/gi, function (s) {
          return String.fromCharCode(parseInt(s.replace(/\\u/g, ""), 16));
        })
      );

      // 提取高清图URL
      const highResRegex = /"HighResCompWatermarked":"(.+?)"/;
      const highResMatch = scriptContent.match(highResRegex);
      const highResUrlEncoded = highResMatch[1];
      const highResUrl = decodeURIComponent(
        highResUrlEncoded.replace(/\\u[\dA-F]{4}/gi, function (s) {
          return String.fromCharCode(parseInt(s.replace(/\\u/g, ""), 16));
        })
      );

      // 解码URL并发送消息
      const decodedThumbUrl = decodeURIComponent(thumbUrl);
      const decodedHighResUrl = decodeURIComponent(highResUrl);

      console.log(decodedThumbUrl, decodedHighResUrl, currentUrl);

      if (button.tagName === "A") {
        currentButton = button;
        console.log("getty_detail");
        await chrome.runtime.sendMessage({
          type: "getty_detail",
          data: {
            url_612: decodedThumbUrl,
            url_detail: decodedHighResUrl,
            landingUrl: currentUrl,
          },
        });
      }
    } catch (error) {
      console.error("Error in detail button handler:", error);
      button.innerHTML = BUTTON_CONTENT.DOWNLOAD;
    }
  } else {
    button.innerHTML = MESSAGES.LOGIN_REQUIRED;
  }
}

/**
 * 处理搜索页按钮点击
 * @param {Event} event - 点击事件
 */
async function handleSearchButtonClick(event) {
  event.stopPropagation();
  event.preventDefault();

  const button = event.target;
  if (button.innerHTML !== BUTTON_CONTENT.DOWNLOAD) return;

  button.innerHTML = BUTTON_CONTENT.WAITING;

  try {
    // 获取缩略图元素
    const thumbElement = button.parentElement.querySelector(
      SELECTORS.THUMB_IMAGE
    );
    let thumbUrl = "";

    if (!thumbElement || !thumbElement.src) {
      Swal.fire({
        icon: "warning",
        html: MESSAGES.DOWNLOAD_NOT_SUPPORTED,
      });
      button.innerHTML = BUTTON_CONTENT.DOWNLOAD;
      return;
    } else {
      thumbUrl = thumbElement.src;
    }

    // 获取图片详情链接
    let detailUrl = button.parentElement.querySelector("a").href;

    // 处理ID格式的URL
    if (detailUrl.includes("/editorial-images")) {
      const idRegex = /\/id\/(\d+?)\//;
      const idMatch = thumbUrl.match(idRegex);
      const imageId = idMatch[1];
      detailUrl = MESSAGES.GETTY_DETAIL_URL + imageId;
    }

    // 获取高清图URL
    const highResUrl = await getGettyResponse(detailUrl);

    console.log(thumbUrl, highResUrl, detailUrl);

    if (button.tagName === "A") {
      currentButton = button;
      console.log("sending message to background.js");
      await chrome.runtime.sendMessage({
        type: "getty_search",
        data: {
          url_612: thumbUrl,
          url_detail: highResUrl,
          landingUrl: detailUrl,
        },
      });
    }
  } catch (error) {
    console.error("Error in search button handler:", error);
    button.innerHTML = BUTTON_CONTENT.DOWNLOAD;
  }
}

/**
 * 设置详情页鼠标进出事件
 * @param {string} selector - DOM选择器
 * @param {Function} buttonCreator - 按钮创建函数
 */
function setupDetailMouseEnterLeave(selector, buttonCreator) {
  const element = document.querySelector(selector);
  let button = null;

  if (!element) return;

  element.addEventListener("mouseenter", () => {
    if (button) return;
    button = buttonCreator(PAGE_TYPES.DETAIL);
    element.insertAdjacentElement("beforeend", button);
  });

  element.addEventListener("mouseleave", () => {
    if (button) {
      button.remove();
      button = null;
    }
  });
}

/**
 * 设置搜索页鼠标进出事件
 * @param {string} selector - DOM选择器
 * @param {Function} buttonCreator - 按钮创建函数
 */
function setupSearchMouseEnterLeave(selector, buttonCreator) {
  const elements = document.querySelectorAll(selector);
  let button = null;

  if (!elements.length) return;

  elements.forEach((element) => {
    element.style.position = "relative";

    if (element) {
      // 阻止默认点击事件，改为在新标签页打开
      element.addEventListener("click", function (event) {
        event.stopPropagation();
        event.preventDefault();
        const link = element.querySelector("a").href;
        window.open(link, "_blank");
      });

      // 鼠标进入时显示下载按钮
      element.addEventListener("mouseenter", () => {
        if (button) return;
        button = buttonCreator(PAGE_TYPES.SEARCH);
        element.insertAdjacentElement("beforeend", button);
      });

      // 鼠标离开时移除下载按钮
      element.addEventListener("mouseleave", () => {
        if (button) {
          button.remove();
          button = null;
        }
      });
    }
  });
}

/**
 * 获取Getty图片详情响应
 * @param {string} url - 图片详情页URL
 * @returns {Promise<string|null>} 高清图URL或null
 */
async function getGettyResponse(url) {
  try {
    const response = await fetch(url);
    const html = await response.text();
    return extract_getty_2048wm(html);
  } catch (error) {
    console.error(MESSAGES.ERROR_FETCHING, error);
    return null;
  }
}

/**
 * 从HTML中提取高清图片URL
 * @param {string} html - 页面HTML内容
 * @returns {string|null} 高清图URL或null
 */
function extract_getty_2048wm(html) {
  const regex = /"HighResComp":"(.+?)"/;
  const match = html.match(regex);

  if (!match) return null;

  const encodedUrl = match[1];
  const jsonDecoded = JSON.parse('"' + encodedUrl + '"');
  return decodeURIComponent(jsonDecoded);
}

/**
 * HTML解码函数
 * @param {string} html - 编码的HTML字符串
 * @returns {string} 解码后的HTML字符串
 */
function htmlDecode(html) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  return doc.documentElement.textContent;
}

/**
 * 设置DOM变化观察器
 */
function setupMutationObserver() {
  const observer = new MutationObserver((mutations) => {
    for (const { addedNodes } of mutations) {
      for (const node of addedNodes) {
        if (node.nodeType === Node.ELEMENT_NODE && processNewElement(node)) {
          return;
        }
      }
    }
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
  });
}

/**
 * 处理新添加的DOM元素
 * @param {HTMLElement} element - 新添加的元素
 * @returns {boolean} 是否处理了元素
 */
function processNewElement(element) {
  // 检查是否是详情页预览元素
  if (
    element.matches?.(SELECTORS.DETAIL_PREVIEW) ||
    element.querySelector?.(SELECTORS.DETAIL_PREVIEW)
  ) {
    setupDetailBtn();
    return true;
  }

  // 检查是否是搜索页预览元素
  if (
    element.matches?.(SELECTORS.SEARCH_PREVIEW) ||
    element.querySelector?.(SELECTORS.SEARCH_PREVIEW)
  ) {
    setupSearchBtn();
    return true;
  }

  return false;
}

/**
 * 设置详情页下载按钮
 */
function setupDetailBtn() {
  setupDetailMouseEnterLeave(SELECTORS.DETAIL_PREVIEW, createDownloadButton);
}

/**
 * 设置搜索页下载按钮
 */
function setupSearchBtn() {
  setupSearchMouseEnterLeave(SELECTORS.SEARCH_PREVIEW, createDownloadButton);
}

/**
 * 初始化扩展
 */
function initialize() {
  // 检测页面类型
  detectPageType();

  // 监听来自后台脚本的消息
  chrome.runtime.onMessage.addListener(
    async (message, sender, sendResponse) => {
      if (message.status === "success") {
        // 显示成功通知
        new Notify({
          status: "success",
          title: "Added to download",
          text: message.data.message,
          effect: "fade",
          speed: 300,
          customClass: "",
          customIcon: "",
          showIcon: true,
          showCloseButton: true,
          autoclose: true,
          autotimeout: 3000,
          notificationsGap: null,
          notificationsPadding: null,
          type: "notification",
          position: "right top",
          customWrapper: "",
        });
        currentButton.innerHTML = BUTTON_CONTENT.ADDED;
      } else if (message.status === "error") {
        // 显示错误消息
        Swal.fire({
          icon: "error",
          html:
            '<div><div>You have recently downloaded image <span style="color: #ffdd00;">' +
            message.data.error +
            "</span></div><div>Check it in the download list.</div></div>",
        });
        currentButton.innerHTML = BUTTON_CONTENT.DOWNLOAD;
      } else if (message.status === "warning") {
        // 显示警告消息
        Swal.fire({
          icon: "warning",
          html:
            '<div><div>You have recently downloaded image <span style="color: #ffdd00;">' +
            message.data.warning +
            "</span></div><div>Check it in the download list.</div></div>",
        });
        currentButton.innerHTML = BUTTON_CONTENT.DOWNLOAD;
      }
    }
  );

  // 当文档加载完成时设置按钮
  if (document.readyState !== "loading") {
    if (currentPage === PAGE_TYPES.SEARCH) {
      setupSearchBtn();
    }
    if (currentPage === PAGE_TYPES.DETAIL) {
      setupDetailBtn();
    }
  }

  // 设置DOM变化观察器
  setupMutationObserver();
}

// 启动扩展
initialize();
