// 常量定义
const API_HOST = "http://127.0.0.1:3000";

// 存储初始token（模拟数据）
chrome.storage.local.set({ token: "123", refresh_token: "456" });

/**
 * 处理来自内容脚本的消息
 * @param {Object} message - 接收到的消息
 * @param {Object} sender - 消息发送者信息
 * @param {Function} sendResponse - 用于发送响应的函数
 */
chrome.runtime.onMessage.addListener(async function (
  message,
  sender,
  sendResponse
) {
  // 初始化变量
  let sourceType = null;
  let thumbnailUrl = null;
  let detailUrl = null;
  let landingUrl = null;

  // 根据消息类型提取相关数据
  if (message.type === "getty_search") {
    thumbnailUrl = message.data.url_612;
    detailUrl = message.data.url_detail;
    landingUrl = message.data.landingUrl;
    sourceType = "getty";
  }

  if (message.type === "getty_detail") {
    thumbnailUrl = message.data.url_612;
    detailUrl = message.data.url_detail;
    landingUrl = message.data.landingUrl;
    sourceType = "getty";
  }

  if (message.type === "alamy_search") {
    thumbnailUrl = message.data.thumb170;
    detailUrl = message.data.url_612;
    landingUrl = message.data.landingUrl;
    sourceType = "alamy";
  }

  if (message.type === "alamy_detail") {
    thumbnailUrl = message.data.thumb170;
    detailUrl = message.data.thumb640;
    landingUrl = message.data.landingUrl;
    sourceType = "alamy";
  }

  if (message.type === "imago_search") {
    thumbnailUrl = message.data.url_thumb;
    detailUrl = message.data.url_detail;
    landingUrl = message.data.landingUrl;
    sourceType = "imago";
  }

  if (message.type === "imago_detail") {
    thumbnailUrl = message.data.url_thumb;
    detailUrl = message.data.url_detail;
    landingUrl = message.data.landingUrl;
    sourceType = "imago";
  }

  if (message.type === "ap_detail") {
    thumbnailUrl = "";
    detailUrl = message.data.url_detail;
    landingUrl = "";
    sourceType = "ap";
  }

  if (message.type === "freepik_search" || message.type === "freepik_detail") {
    thumbnailUrl = message.data.url_thumb;
    detailUrl = message.data.url_detail;
    landingUrl = message.data.landingUrl;
    sourceType = "freepik";
  }

  if (message.type === "ss_search" || message.type === "ss_detail") {
    thumbnailUrl = message.data.url_thumb;
    detailUrl = message.data.url_detail;
    landingUrl = message.data.landingUrl;
    sourceType = "ss";
  }

  if (message.type === "istock_search" || message.type === "istock_detail") {
    thumbnailUrl = message.data.url_612;
    detailUrl = message.data.url_detail;
    landingUrl = message.data.landingUrl;
    sourceType = "istock";
  }

  if (
    message.type === "adobestock_search" ||
    message.type === "adobestock_detail"
  ) {
    thumbnailUrl = message.data.url_thumb;
    detailUrl = message.data.url_detail;
    landingUrl = message.data.landingUrl;
    sourceType = "adobestock";
  }

  console.log(sourceType, message.data);

  try {
    // 发送下载请求到API
    const response = await fetch(API_HOST + "/api/" + sourceType + "/dl/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        url_thumb_nw: thumbnailUrl,
        url_image_wm: detailUrl,
        url_landingUrl: landingUrl,
      }),
    });

    const data = await response.json();
    console.log(response.status, data);

    if (response.status === 500) {
      await notice("错误提示", data.error);
      return;
    }

    if (response.ok) {
      // await notice("成功提示", data.message);
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length > 0) {
          chrome.tabs.sendMessage(tabs[0].id, {
            status: 'success',
            data: data,
          });
        }
      });
    } else {
      await notice("错误提示", "未知错误，请稍后重试");
      return;
    }
  } catch (error) {
    console.error("Error fetching data:", error);
    return null;
  }
});

/**
 * 显示通知
 * @param {string} title - 通知标题
 * @param {string} message - 通知内容
 */
async function notice(title, message) {
  const iconUrl = chrome.runtime.getURL("images/icon-48.png");

  chrome.notifications.create(
    {
      type: "basic",
      iconUrl: iconUrl,
      title: title,
      message: message,
    },
    function (notificationId) {
      if (chrome.runtime.lastError) {
        console.error(chrome.runtime.lastError.message);
      } else {
        console.log(notificationId);
      }
    }
  );
}
