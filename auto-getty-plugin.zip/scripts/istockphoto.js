// iStockPhoto 自动下载插件脚本

// 配置常量
const SELECTORS = {
  DETAIL_PREVIEW: 'picture[data-testid="hero-picture"]',
  SEARCH_PREVIEW: 'div[data-testid="gallery-mosaic-asset"]',
  THUMB_IMAGE: "img",
};

// 按钮内容常量
const BUTTON_CONTENT = {
  DOWNLOAD:
    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">\n        <path d="M14,14H2a1,1,0,0,0,0,2H14a1,1,0,0,0,0-2Z" fill="#000000"></path>\n        <path d="M7.293,11.707a1,1,0,0,0,1.414,0l5-5a1,1,0,1,0-1.414-1.414L9,8.586V1A1,1,0,0,0,7,1V8.586L3.707,5.293A1,1,0,0,0,2.293,6.707Z"></path>\n      </svg>Download',
  WAITING:
    '<svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 16 16">\n        <title>dots anim 2</title>\n        <g fill="#000000" class="nc-icon-wrapper">\n          <g class="nc-loop-dots-2-16-icon-f">\n            <circle cx="8" cy="1.5" fill="#000000" r="1.5" opacity="0.6"></circle>\n            <circle cx="12.596" cy="3.404" fill="#000000" r="1.5" opacity="0.8"></circle>\n            <circle cx="14.5" cy="8" fill="#000000" r="1.5"></circle>\n            <circle cx="12.596" cy="12.596" fill="#000000" r="1.5" opacity="0.4"></circle>\n            <circle cx="8" cy="14.5" fill="#000000" r="1.5" opacity="0.4"></circle>\n            <circle cx="3.404" cy="12.596" fill="#000000" r="1.5" opacity="0.4"></circle>\n            <circle cx="1.5" cy="8" fill="#000000" r="1.5" opacity="0.4"></circle>\n            <circle cx="3.404" cy="3.404" fill="#000000" r="1.5" opacity="0.4"></circle>\n          </g>\n          <style>.nc-loop-dots-2-16-icon-f{--animation-duration:0.8s;transform-origin:8px 8px;animation:nc-loop-dots-2-anim var(--animation-duration) infinite steps(8,start)}@keyframes nc-loop-dots-2-anim{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}</style>\n        </g>\n      </svg>Waiting',
  ADDED:
    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">\n        <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"></path>\n      </svg>Added',
};

// 页面类型常量
const PAGE_TYPES = {
  SEARCH: "search",
  DETAIL: "detail",
};

// 消息类型常量
const MESSAGE_TYPES = {
  IStockDetail: "istock_detail",
  IStockSearch: "istock_search",
};

// 全局变量
let currentButton = null;
let currentUrl = window.location.href;
let currentPage = null;

// 初始化页面类型
currentUrl.includes("/search")
  ? (currentPage = PAGE_TYPES.SEARCH)
  : (currentPage = PAGE_TYPES.DETAIL);

/**
 * 检查用户是否已登录并获取token
 * @returns {Promise<string|null>} 用户token或null
 */
async function checkToken() {
  return new Promise((resolve) => {
    chrome.storage.local.get(
      ["token", "refresh_token"],
      async function (result) {
        result.token && result.refresh_token
          ? resolve(result.token)
          : resolve(null);
      }
    );
  });
}

/**
 * 创建下载按钮
 * @param {string} pageType - 页面类型
 * @returns {HTMLAnchorElement} 下载按钮元素
 */
function createDownloadButton(pageType = null) {
  const button = document.createElement("a");
  button.innerHTML = BUTTON_CONTENT.DOWNLOAD;

  Object.assign(button.style, {
    position: "absolute",
    top: "0",
    right: "0",
    zIndex: "11",
    width: "120px",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  });

  button.classList.add("download");
  button.download = true;

  // 根据页面类型添加不同的点击事件处理程序
  if (pageType === PAGE_TYPES.DETAIL) {
    console.log("detail");
    button.addEventListener("click", handleDetailButtonClick);
  } else if (pageType === PAGE_TYPES.SEARCH) {
    console.log("search");
    button.addEventListener("click", handleSearchButtonClick);
  }

  return button;
}

/**
 * 处理详情页下载按钮点击
 * @param {Event} event - 点击事件
 */
async function handleDetailButtonClick(event) {
  event.stopPropagation();
  event.preventDefault();

  const button = event.target;
  if (button.innerHTML !== BUTTON_CONTENT.DOWNLOAD) return;

  button.innerHTML = BUTTON_CONTENT.WAITING;

  // 获取图片URL和详情信息
  const imageUrl = document
    .querySelector('meta[itemprop="contentUrl"]')
    .getAttribute("content");
  const parentElement = button.parentElement;
  const imgElement = parentElement.querySelector("img");
  const imageSource = imgElement ? imgElement.srcset : null;
  const landingUrl = currentUrl;

  console.log(imageUrl, imageSource, landingUrl);

  // 发送消息到background script
  if (event.currentTarget.tagName === "A") {
    currentButton = button;
    console.log("sending message to background.js");
    await chrome.runtime.sendMessage({
      type: MESSAGE_TYPES.IStockDetail,
      data: {
        url_612: imageUrl,
        url_detail: imageSource,
        landingUrl: landingUrl,
      },
    });
  }
}

/**
 * 处理搜索页下载按钮点击
 * @param {Event} event - 点击事件
 */
async function handleSearchButtonClick(event) {
  event.stopPropagation();
  event.preventDefault();

  const button = event.target;
  if (button.innerHTML !== BUTTON_CONTENT.DOWNLOAD) return;

  button.innerHTML = BUTTON_CONTENT.WAITING;

  // 获取图片URL
  const imgElement = button.parentElement.querySelector("img");
  console.log(112, imgElement);

  let imageUrl = "";
  if (!imgElement || !imgElement.src) {
    Swal.fire({
      icon: "warning",
      html: "<div> <span style='color: #ffdd00;'>Download not supported</span></div>",
    });
    return;
  } else {
    imageUrl = imgElement.src;
  }

  // 获取图片详情页URL和2048px版本URL
  const detailPageUrl = button.parentElement.querySelector("a").href;
  const largeImageUrl = await getIstockResponse(detailPageUrl);

  console.log(111, imgElement, imageUrl, largeImageUrl, detailPageUrl);

  // 发送消息到background script
  if (event.target.tagName === "A") {
    currentButton = button;
    console.log("sending message to background.js");
    await chrome.runtime.sendMessage({
      type: MESSAGE_TYPES.IStockSearch,
      data: {
        url_612: imageUrl,
        url_detail: largeImageUrl,
        landingUrl: detailPageUrl,
      },
    });
  }
}

/**
 * 设置详情页鼠标悬停/离开事件
 * @param {string} selector - 选择器
 * @param {Function} buttonCreator - 按钮创建函数
 */
function setupDetailMouseEnterLeave(selector, buttonCreator) {
  const element = document.querySelector(selector);
  let button = null;

  if (!element) return;

  element.addEventListener("mouseenter", () => {
    if (button) return;
    button = buttonCreator(PAGE_TYPES.DETAIL);
    element.insertAdjacentElement("beforeend", button);
  });

  element.addEventListener("mouseleave", () => {
    if (button) {
      button.remove();
      button = null;
    }
  });
}

/**
 * 设置搜索页鼠标悬停/离开事件
 * @param {string} selector - 选择器
 * @param {Function} buttonCreator - 按钮创建函数
 */
function setupSearchMouseEnterLeave(selector, buttonCreator) {
  const elements = document.querySelectorAll(selector);
  let button = null;

  if (!elements.length) return;

  elements.forEach((element) => {
    element.style.position = "relative";

    if (!element) return;

    element.addEventListener("mouseenter", () => {
      if (button) return;
      button = buttonCreator(PAGE_TYPES.SEARCH);
      element.insertAdjacentElement("beforeend", button);
    });

    element.addEventListener("mouseleave", () => {
      if (button) {
        button.remove();
        button = null;
      }
    });
  });
}

/**
 * 获取iStock图片响应
 * @param {string} url - 图片详情页URL
 * @returns {Promise<string|null>} 2048px版本图片URL
 */
async function getIstockResponse(url) {
  try {
    const response = await fetch(url);
    const html = await response.text();
    const imageUrl = extract_istock_2048wm(html);
    return imageUrl;
  } catch (error) {
    console.error("Error fetching data:", error);
    return null;
  }
}

/**
 * 从HTML中提取2048px版本图片URL
 * @param {string} html - HTML内容
 * @returns {string|null} 2048px版本图片URL
 */
function extract_istock_2048wm(html) {
  const regex =
    /<source\s+srcSet="([^"]*?2048x2048[^"]*?)"\s+type="image\/webp"\/>/;
  const match = html.match(regex);

  if (!match) return null;

  let imageUrl = match[1];
  imageUrl = htmlDecode(imageUrl);

  // 解析JSON并解码URI
  const parsedUrl = JSON.parse('"' + imageUrl + '"');
  return decodeURIComponent(parsedUrl);
}

/**
 * HTML解码函数
 * @param {string} html - 编码的HTML字符串
 * @returns {string} 解码后的字符串
 */
function htmlDecode(html) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  return doc.documentElement.textContent;
}

/**
 * 设置DOM变化监听
 */
function setupMutationObserver() {
  const observer = new MutationObserver((mutations) => {
    for (const { addedNodes } of mutations) {
      for (const node of addedNodes) {
        if (node.nodeType === Node.ELEMENT_NODE && processNewElement(node)) {
          return;
        }
      }
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

/**
 * 处理新添加的DOM元素
 * @param {Node} element - 新添加的元素
 * @returns {boolean} 是否处理了元素
 */
function processNewElement(element) {
  if (
    element.matches?.(`.${SELECTORS.DETAIL_PREVIEW}`) ||
    element.querySelector?.(SELECTORS.DETAIL_PREVIEW)
  ) {
    setupDetailBtn();
    return true;
  }

  if (
    element.matches?.(`.${SELECTORS.SEARCH_PREVIEW}`) ||
    element.querySelector?.(SELECTORS.SEARCH_PREVIEW)
  ) {
    setupSearchBtn();
    return true;
  }

  return false;
}

/**
 * 设置详情页下载按钮
 */
function setupDetailBtn() {
  // setupDetailMouseEnterLeave(SELECTORS.DETAIL_PREVIEW, createDownloadButton);
}

/**
 * 设置搜索页下载按钮
 */
function setupSearchBtn() {
  setupSearchMouseEnterLeave(SELECTORS.SEARCH_PREVIEW, createDownloadButton);
}

/**
 * 初始化插件
 */
function initialize() {
  // 立即执行初始化，不需要等待DOM加载完成
  if (document.readyState !== "loading") {
    if (currentPage === PAGE_TYPES.SEARCH) {
      setupSearchBtn();
    }
    if (currentPage === PAGE_TYPES.DETAIL) {
      setupDetailBtn();
    }
  }

  // 设置DOM变化监听，处理动态加载的内容
  setupMutationObserver();
}

// 监听来自background script的消息
chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
  if (message.status === "success") {
    new Notify({
      status: "success",
      title: "Added to download",
      text: message.data.message,
      effect: "fade",
      speed: 300,
      customClass: "",
      customIcon: "",
      showIcon: true,
      showCloseButton: true,
      autoclose: true,
      autotimeout: 3000,
      notificationsGap: null,
      notificationsPadding: null,
      type: "filled",
      position: "right top",
      customWrapper: "",
    });
    currentButton.innerHTML = BUTTON_CONTENT.ADDED;
  }

  if (message.status === "error") {
    Swal.fire({
      icon: "error",
      html:
        "<div><div>You have recently downloaded image <span style='color: #ffdd00;'>" +
        message.error.error +
        "</span></div>",
    });
    currentButton.innerHTML = BUTTON_CONTENT.DOWNLOAD;
  }

  if (message.status === "warning") {
    Swal.fire({
      icon: "warning",
      html:
        "<div><div>You have recently downloaded image <span style='color: #ffdd00;'>" +
        message.error.warning +
        "</span></div><div>Check it in the download list.</div></div>",
    });
    currentButton.innerHTML = BUTTON_CONTENT.ADDED;
  }
});

// 初始化插件
initialize();
