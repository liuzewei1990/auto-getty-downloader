// ========== 你只改这里的选择器 ==========
const CONFIG = {
  itemSelector: '.download',
  nextPageSelector: '[data-testid="pagination-button-next"]',
  delayBetweenItems: 1000,
  delayAfterNextPage: 1500
}
// ======================================

let isRunning = false
let stopFlag = false
let startBtn
let pageInput

// 1. 创建控制面板
function createPanel() {
  const panel = document.createElement('div')
  panel.style.position = 'fixed'
  panel.style.zIndex = '999'
  panel.style.bottom = '20px'
  panel.style.left = '50%'
  panel.style.transform = 'translateX(-50%)'
  panel.style.background = '#fff'
  panel.style.padding = '10px 16px'
  panel.style.borderRadius = '8px'
  panel.style.boxShadow = '0 2px 12px rgba(0,0,0,0.2)'
  panel.style.display = 'flex'
  panel.style.alignItems = 'center'
  panel.style.gap = '8px'
  panel.style.fontSize = '14px'

  const text1 = document.createElement('span')
  text1.textContent = '从当前页到第'

  pageInput = document.createElement('input')
  pageInput.type = 'number'
  pageInput.min = '1'
  // 默认值设为当前页+5，更实用
  pageInput.value = getCurrentPage() + 5
  pageInput.style.width = '50px'
  pageInput.style.padding = '4px'

  const text2 = document.createElement('span')
  text2.textContent = '页'

  startBtn = document.createElement('button')
  startBtn.textContent = '开始下载'
  startBtn.style.padding = '4px 12px'
  startBtn.style.backgroundColor = '#1677ff'
  startBtn.style.color = '#fff'
  startBtn.style.border = 'none'
  startBtn.style.borderRadius = '4px'
  startBtn.style.cursor = 'pointer'

  startBtn.onclick = () => {
    if (isRunning) {
      stopFlag = true
      setButtonStopped()
      showToast('已停止任务')
      return
    }
    const targetPage = parseInt(pageInput.value) || getCurrentPage() + 5
    startTask(targetPage)
  }

  panel.appendChild(text1)
  panel.appendChild(pageInput)
  panel.appendChild(text2)
  panel.appendChild(startBtn)
  document.body.appendChild(panel)
}

// 核心：从URL的page参数获取当前页码
function getCurrentPage() {
  const urlParams = new URLSearchParams(window.location.search)
  const pageNum = parseInt(urlParams.get('page'))
  // 如果没有page参数，默认返回1
  return isNaN(pageNum) ? 1 : pageNum
}

// 按钮状态切换
function setButtonRunning() {
  startBtn.textContent = '停止下载'
  startBtn.style.backgroundColor = '#ff4d4f'
  pageInput.disabled = true
}

function setButtonStopped() {
  startBtn.textContent = '开始下载'
  startBtn.style.backgroundColor = '#1677ff'
  pageInput.disabled = false
  isRunning = false
}

// 轻提示
function showToast(msg) {
  const toast = document.createElement('div')
  toast.innerText = msg
  toast.style.position = 'fixed'
  toast.style.top = '20px'
  toast.style.left = '50%'
  toast.style.transform = 'translateX(-50%)'
  toast.style.background = 'rgba(0,0,0,0.7)'
  toast.style.color = '#fff'
  toast.style.padding = '10px 20px'
  toast.style.borderRadius = '6px'
  toast.style.zIndex = '999999'
  toast.style.fontSize = '14px'
  document.body.appendChild(toast)

  setTimeout(() => {
    if (document.body.contains(toast)) {
      document.body.removeChild(toast)
    }
  }, 2000)
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

// 核心任务（从URL的page页开始执行）
async function startTask(targetPage) {
  isRunning = true
  stopFlag = false
  setButtonRunning()

  const currentPage = getCurrentPage()
  // 校验目标页不能小于当前页
  if (targetPage < currentPage) {
    showToast('目标页不能小于当前页！')
    setButtonStopped()
    return
  }

  showToast(`开始执行：从第 ${currentPage} 页到第 ${targetPage} 页`)
  let currentExecPage = currentPage

  while (currentExecPage <= targetPage && !stopFlag) {
    console.log(`第 ${currentExecPage} 页 / 目标 ${targetPage} 页`)

    // 等待页面加载完成（翻页后可能需要等URL更新）
    await waitForPageUpdate(currentExecPage)

    const items = Array.from(document.querySelectorAll(CONFIG.itemSelector))
    if (items.length === 0) {
      showToast(`第 ${currentExecPage} 页无可点击项，已停止`)
      break
    }

    // 点击当前页所有列表项
    for (const item of items) {
      if (stopFlag) break
      try {
        item.scrollIntoView({ block: 'center' })
        item.style.display = 'block'
        item.click()
        await delay(CONFIG.delayBetweenItems)
      } catch (e) {
        console.log(`点击项失败:`, e)
      }
    }

    // 停止/到达目标页则退出
    if (stopFlag || currentExecPage >= targetPage) break

    // 找下一页按钮并点击
    const nextBtn = document.querySelector(CONFIG.nextPageSelector)
    if (!nextBtn || nextBtn.disabled || nextBtn.classList.contains('disabled')) {
      showToast('已到最后一页，无下一页按钮')
      break
    }

    nextBtn.scrollIntoView({ block: 'center' })
    nextBtn.click()
    currentExecPage++
    await delay(CONFIG.delayAfterNextPage)
  }

  if (!stopFlag) {
    showToast(`任务完成：已执行到第 ${targetPage} 页`)
  }

  setButtonStopped()
}

// 等待页面URL的page参数更新（防止翻页后页码没同步）
async function waitForPageUpdate(expectedPage) {
  let waitCount = 0
  while (getCurrentPage() !== expectedPage && waitCount < 10) {
    await delay(300)
    waitCount++
  }
}

// 加载面板
if (document.querySelector('[data-testid="gallery-items-container"]')) {
  createPanel()
}
console.log(`✅ 自动点击工具已加载，当前页：${getCurrentPage()}`)
