class WSChecker {
  constructor(url, options = {}) {
    this.url = url
    this.options = {
      reconnectInterval: 1000,
      maxReconnectAttempts: Infinity,
      ...options
    }
    this.socket = null
    this.reconnectAttempts = 0
    this.isConnected = false
    this.callbacks = {
      onOpen: [],
      onMessage: [],
      onClose: [],
      onError: []
    }
  }

  connect() {
    console.log('connect', this.url)
    if (
      this.socket &&
      (this.socket.readyState === WebSocket.OPEN || this.socket.readyState === WebSocket.CONNECTING)
    ) {
      return
    }

    try {
      this.socket = new WebSocket(this.url)

      this.socket.onopen = (event) => {
        this.isConnected = true
        this.reconnectAttempts = 0
        this.callbacks.onOpen.forEach((callback) => callback(event))
      }

      this.socket.onmessage = (event) => {
        this.callbacks.onMessage.forEach((callback) => callback(event))
      }

      this.socket.onclose = (event) => {
        this.isConnected = false
        this.callbacks.onClose.forEach((callback) => callback(event))
        this.handleReconnect()
      }

      this.socket.onerror = (event) => {
        this.callbacks.onError.forEach((callback) => callback(event))
      }
    } catch (error) {
      console.error('WebSocket connection error:', error)
      this.handleReconnect()
    }
  }

  handleReconnect() {
    if (this.reconnectAttempts < this.options.maxReconnectAttempts) {
      this.reconnectAttempts++
      setTimeout(() => {
        console.log(`Attempting to reconnect (${this.reconnectAttempts})...`)
        this.connect()
      }, this.options.reconnectInterval)
    } else {
      console.error('Max reconnect attempts reached')
    }
  }

  on(event, callback) {
    if (this.callbacks[event]) {
      this.callbacks[event].push(callback)
    }
  }

  send(data) {
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      this.socket.send(data)
      return true
    }
    return false
  }

  close() {
    if (this.socket) {
      this.socket.close()
    }
  }

  getReadyState() {
    return this.socket ? this.socket.readyState : WebSocket.CLOSED
  }
}

console.log('WSChecker', WSChecker)
new WSChecker('ws://127.0.0.1:13132').connect()
